package com.plugins;

import com.example.plugincall.AbstractPlugin;

public class Plugin1 extends AbstractPlugin {

	@Override
	public void start(String n) {

		String str = "'1'='1'";
		String p = "OR";
		boolean a = n.contains(str) || n.contains(p);
		if (a == true) {
			System.out.print(1);
		} else {
			System.out.print(0);
		}
	}

	@Override
	public void run() {

	}

	@Override
	public void close() {

	}
}
