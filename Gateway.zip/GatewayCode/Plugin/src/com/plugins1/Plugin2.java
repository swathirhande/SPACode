
package com.plugins1;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.example.plugincall.AbstractPlugin;

public class Plugin2 extends AbstractPlugin {
	public static boolean a;
	static String c = null;

	@Override
	public void start(String n) {
		try {

			c = isUserLoggedIn(n) ? "1" : "0";
			System.out.print(c);

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static boolean isUserLoggedIn(String acc) {

		try {

			String[] parts = acc.split("&");
			Map<String, String> map = new HashMap<String, String>();
			for (String part : parts) {
				map.put(part.split("=")[0], part.split("=")[1]);
			}
			String acNo = map.get("accountno");

			List<Object> list = new ArrayList<Object>();
			BufferedReader br = Files.newBufferedReader(Paths.get("C:\\Temp\\logs\\banking-logs.log"));
			// br returns as stream and convert it into a List
			list = br.lines().collect(Collectors.toList());
			for (Object element : list) {
				String data = (String) element;
				String[] substrings = data.split("[:]");
				a = substrings[5].contains(acNo) && substrings[4].contains("Login Successful for user");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return a;
	}

	@Override
	public void run() {

	}

	@Override
	public void close() {

	}
}
